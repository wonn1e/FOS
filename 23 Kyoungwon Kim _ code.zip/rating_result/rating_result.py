# -*- coding: utf-8 -*-
from konlpy.tag import Twitter
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array


sc = SparkContext()
sqlContext = SQLContext(sc)

kmeans = sc.pickleFile('/cluster_sim')
cosine = sc.pickleFile('/cosine_result_pickle')

final = kmeans.join(cosine).map(lambda ((k1,k2),(m,c)) : ((k1,k2),m+c)).saveAsPickleFile('/final_result')

#documents = sqlContext.createDataFrame(sc.pickleFile('/merged_file').map(lambda x : [x['eval_id'],x['no'],create_wordbag(x),x['professor'],x['lec_code'][:4],x['lec_code'][5],x['eval_total'],x['eval_id'],x['eval_content']]),['eval_id','no','words','prof_name','department','grade','eval_total','eval_id','eval_content'])


