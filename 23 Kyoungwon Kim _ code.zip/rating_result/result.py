# -*- coding: utf-8 -*-
from konlpy.tag import Twitter
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array


sc = SparkContext()
sqlContext = SQLContext(sc)

codes = sc.pickleFile('/final_result').map(lambda ((k1,k2),v) : k1).distinct().collect()
for code in codes:
	result =  sc.pickleFile('/final_result').filter(lambda ((k1,k2),v) : code in k1).map(lambda ((k1,k2),v) : (v,(k1,k2))).sortByKey(ascending=False).map(lambda (v,(k1,k2)) : ((k1,k2),v))

	f = open('Similarity/'+ code +'.tsv','w')
	f.write('lecture' + '\t' + 'similarity' + '\n')
	for a in result.take(100):
		if str(a[0][1]) != code:
			f.write(str(a[0][1])+'\t' + str(a[1]/2.0) + '\n')

#final = kmeans.join(cosine).map(lambda ((k1,k2),(m,c)) : ((k1,k2),m+c)).saveAsPickleFile('/final_result')

#documents = sqlContext.createDataFrame(sc.pickleFile('/merged_file').map(lambda x : [x['eval_id'],x['no'],create_wordbag(x),x['professor'],x['lec_code'][:4],x['lec_code'][5],x['eval_total'],x['eval_id'],x['eval_content']]),['eval_id','no','words','prof_name','department','grade','eval_total','eval_id','eval_content'])


