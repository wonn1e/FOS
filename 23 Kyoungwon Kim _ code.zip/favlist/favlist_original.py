# -*- coding: utf-8 -*-
from konlpy.tag import Twitter
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array


sc = SparkContext()
sqlContext = SQLContext(sc)

data = sc.pickleFile('/merged_file')

user_df = sqlContext.createDataFrame(data.map(lambda x : [x['mb_no'],x['lec_code'][0:7],x['eval_total']]),['mb_no','lec_code','eval_total'])

user_lec = user_df.filter(user_df.eval_total > '3').map(lambda x : (x.mb_no,x.lec_code)).groupByKey()

user_page = sqlContext.createDataFrame(data.map(lambda x : [x['mb_no'],x['eval_id'],x['eval_total']]),['mb_no','page','eval_total']).map(lambda x : (x[0],(x[1],x[2]))).filter(lambda x : x[1][1] > '3').map(lambda x : (x[0],x[1][0]))

user_nick = sqlContext.createDataFrame(data.map(lambda x : (x['mb_no'],x['mb_nick'])), ['mb_no','nick']).rdd.groupByKey()

page_lec = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],x['lec_code'][0:7])),['page','lec_code']).rdd

page_prof = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],x['professor'])),['page','professor']).rdd


user_user = user_lec.cartesian(user_lec).map(lambda (left,right) : ( (left[0],right[0]) ,len( set(left[1]) & set(right[1]) )/len(set(left[1]) ) ) ) 
mb = '16077'

#list of users those who are similar with input user
users = user_user.filter(lambda x: x[0][0] == mb).takeOrdered(10,lambda x: -x[1])
#pages with input user's evaluation
pages = user_page.filter(lambda x : x[0] == mb)

'''
f = open("test.txt",'w')
f.write("the user - page\n")
for u in pages.take(1000):
	f.write(str(u) + '\n')
'''

#rdd version of users
fav_users = sc.parallelize(users).map(lambda x : (x[0][1],x[0][1]))


#pages that similar users have taken excluding those input user had taken
fav_pages = fav_users.join(user_page).map(lambda x: (x[0],x[1][1])).cartesian(user_page.filter(lambda x : x[0] == mb)).filter(lambda (x,y): x[1] != y[1]).map(lambda (x,y) : x).distinct()

'''
f.write('fav-page\n')
for u in fav_pages.take(100):
	f.write(str(u) + '\n')
'''

#pages -> lecture code
fav_lecs = fav_pages.map(lambda x : (x[1],x[0])).join(page_lec).map(lambda x: (x[0],x[1][1])).distinct()

'''
f.write('fav-lec\n')
for u in fav_lecs.take(100):
	f.write(str(u) + '\n')
'''

#professors
fav_profs = fav_pages.map(lambda x : (x[1],x[0])).join(page_prof).map(lambda x:(x[0],x[1][1])).distinct()

'''
f.write('fav-prof\n')
for u in fav_profs.take(100):
	f.write(str(u) + '\n')
'''

#avg evaluation for pages
page_eval = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],float(x['eval_total']))),['page','eval_total']).map(lambda (x,y) : (x,(y,1))).reduceByKey(lambda x,y : (x[0] + y[0] , x[1] + y[1])).map(lambda (x,y) : (x,y[0]/y[1]))

prof_page_eval = page_prof.join(page_eval).map(lambda (x,y) : (y[0],(x,y[1]))).distinct()


#pages that professors taught in descending order of avg(eval_total)
prof_best_pages = fav_profs.map(lambda x : (x[1],(1,1))).join(prof_page_eval).map(lambda x : (x[1][1][1],(x[1][1][0],x[0]))).sortByKey(ascending = False).map(lambda x : (x[1][1],x[1][0]))

#page -> lecture code
prof_best_lec = prof_best_pages.map(lambda x : (x[1],x[0])).join(page_lec).map(lambda x : x[1]).distinct()

'''
f.write('bests\n')
for u in prof_best_pages.take(1000):
	f.write(str(u) + '\n')

for u in prof_best_lec.take(1000):
	f.write(str(u) + '\n')
'''


