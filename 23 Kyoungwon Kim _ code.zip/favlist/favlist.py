# -*- coding: utf-8 -*-
from konlpy.tag import Twitter
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array


sc = SparkContext()
sqlContext = SQLContext(sc)

data = sc.pickleFile('/merged_file')

user_df = sqlContext.createDataFrame(data.map(lambda x : [x['mb_no'],x['lec_code'][0:7],x['eval_total']]),['mb_no','lec_code','eval_total'])

user_lec = user_df.filter(user_df.eval_total > '3').map(lambda x : (x.mb_no,x.lec_code)).groupByKey()

user_page = sqlContext.createDataFrame(data.map(lambda x : [x['mb_no'],x['eval_id'],x['eval_total']]),['mb_no','page','eval_total']).map(lambda x : (x[0],(x[1],x[2]))).filter(lambda x : x[1][1] > '3').map(lambda x : (x[0],x[1][0]))

user_nick = sqlContext.createDataFrame(data.map(lambda x : (x['mb_no'],x['mb_nick'])), ['mb_no','nick']).rdd.groupByKey()

page_lec = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],x['lec_code'][0:7])),['page','lec_code']).rdd.persist()

page_prof = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],x['professor'])),['page','professor']).rdd.persist()

user_numbers = user_df.map(lambda x : x.mb_no).collect()

user_user = user_lec.cartesian(user_lec).map(lambda (left,right) : ( (left[0],right[0]) ,len( set(left[1]) & set(right[1]) )/len(set(left[1]) ) ) ).persist()
 
#avg evaluation for pages
page_eval = sqlContext.createDataFrame(data.map(lambda x : (x['eval_id'],float(x['eval_total']))),['page','eval_total']).map(lambda (x,y) : (x,(y,1))).reduceByKey(lambda x,y : (x[0] + y[0] , x[1] + y[1])).map(lambda (x,y) : (x,y[0]/y[1])).persist()


for mb in user_numbers:
	#list of users those who are similar with input user
	users = user_user.filter(lambda x: x[0][0] == mb).takeOrdered(10,lambda x: -x[1])
	#pages with input user's evaluation
	pages = user_page.filter(lambda x : x[0] == mb).distinct()


	#rdd version of users
	fav_users = sc.parallelize(users).map(lambda x : (x[0][1],x[0][1]))


	#pages that similar users have taken excluding those input user had taken
	fav_pages = fav_users.join(user_page).map(lambda x: (x[0],x[1][1])).cartesian(user_page.filter(lambda x : x[0] == mb)).filter(lambda (x,y): x[1] != y[1]).map(lambda (x,y) : x).distinct()


	#pages -> lecture code
	fav_lecs = fav_pages.map(lambda x : (x[1],x[0])).join(page_lec).map(lambda x: (x[1][0],x[1][1])).distinct()
	
	#professors
	fav_profs = fav_pages.map(lambda x : (x[1],x[0])).join(page_prof).map(lambda x:(x[0],x[1][1])).distinct()
	fav_profs_by_lec = fav_profs.join(page_lec).map(lambda x : (x[1][0],x[1][1])).distinct()
	
	prof_page_eval = page_prof.join(page_eval).map(lambda (x,y) : (y[0],(x,y[1]))).distinct()


	#pages that professors taught in descending order of avg(eval_total)
	prof_best_pages = fav_profs.map(lambda x : (x[1],(1,1))).join(prof_page_eval).map(lambda x : (x[1][1][1],(x[1][1][0],x[0]))).sortByKey(ascending = False).map(lambda x : (x[1][1],x[1][0]))

	#page -> lecture code
	prof_best_lec = prof_best_pages.map(lambda x : (x[1],x[0])).join(page_lec).map(lambda x : x[1]).distinct()

	f = open("data/" + mb + ".csv", 'w')

	f.write("source,target,value\n")
	for u in users:
		#similar user's mb_no & similarity value
		f.write(str(mb)+','+str(u[0][1]) +','+str(1) + '\n')
		lecs = fav_lecs.filter(lambda x : x[0] == u[0][1]).take(2)
		#user_num & lec_code
		for lec in lecs:
			f.write(str(lec[0]) + ',' + str(lec[1]) + ',' + str(1) +'\n')
			prof = fav_profs_by_lec.filter(lambda x : x[1] == lec[1]).take(1)[0]
			f.write(prof[0].strip().encode('utf-8') + ',' + str(prof[1]) + ','+ str(1) + '\n')
			best = prof_best_lec.filter(lambda x : x[0] == prof[0]).take(1)
			best = best[0]
			f.write(best[0].strip().encode('utf-8')+ ',' +str(best[1])+','+ str(1)+'\n')
	'''
	for lec in fav_lecs.take(10):
		#user_num & lec_code
		f.write(str(lec[0]) + ',' + str(lec[1]) + ',' + str(1) +'\n')
		prof = fav_profs_by_lec.filter(lambda x : x[1] == lec[1]).take(1)[0]
		f.write(prof[0].strip().encode('utf-8') + ',' + str(prof[1]) + ','+ str(1) + '\n')
		best = prof_best_lec.filter(lambda x : x[0] == prof[0]).take(1)
		best = best[0]
		f.write(best[0].strip().encode('utf-8')+ ',' +str(best[1])+','+ str(1)+'\n')
	for prof in fav_profs_by_lec.take(10):
		#prof & lec_code
		f.write(prof[0].strip().encode('utf-8') + ',' + str(prof[1]) + ','+ str(1) + '\n')
		best = prof_best_lec.filter(lambda x : x[0] == prof[0]).take(1)
		best = best[0]
		f.write(best[0].strip().encode('utf-8')+ ',' +str(best[1])+','+ str(1)+'\n')
	'''
