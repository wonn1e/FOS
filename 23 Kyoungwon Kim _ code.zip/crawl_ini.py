# -*- coding: utf-8 -*-
from BeautifulSoup import BeautifulSoup
import sys,time,urllib, urllib2, os, socket,random
import multiprocessing as mp



reload(sys)
sys.setdefaultencoding('utf-8')

processList = []

url = "http://klue.kr/ajax/index_loginOk.php"
data = {
	'mb_id' : 'jBDcIDngW9/TjgTbMKFaN9Ac52kDN11HGXk1AGt/nVSmen3pIcMHSWxFiibY/GUmr7aBgo2HxaLk+mIGxKDf4qEWmvNtIrI9xJAfHUgmuQmIXe7tLBOHUxs5b/1ebmNurDENHXmHUgQ7xn6paPmtlXqgqdq3h9TL6pI7nQdexNc=',
	'mb_pw' : 'Vrgz+8IWDsi0bLM7ifxTYWgaj/L579H+iLYS8+fHFRngmIVPQru5MJaSMghOdDOrwiij8IgXE+hJcA5wGmd9S2GZLm3iK4FjJkRNJdP7jSzHGgaIKcdxlf/H4wlJpSU3Yu6IUbLcRbpyajKkPhPxOtmuKiQD4S2ImJb8VJ7aVmE='
}
data = urllib.urlencode(data)
req = urllib2.Request(url, data)
res = urllib2.urlopen(req)
print "========="+res.read()+"=========="
cookie = res.headers.get('Set-Cookie')


def crawl_worker(procId,first,last):
	time.sleep(2*random.random())
	
	directory = 'crawl_data/'+str(procId)
	if not os.path.exists(directory):
		os.makedirs(directory)

	for i in xrange(first,last+1):
		url2="http://klue.kr/lecture.php?no="+str(i)
		req2=urllib2.Request(url2)
		req2.add_header('cookie',cookie)
		while 1:
			try:
				res=urllib2.urlopen(req2,timeout=3)
				lec = BeautifulSoup(res.read())

				for e in lec.findAll('br'):		# <br /> 태그 제거
					e.extract()

				lecInfo = lec.find('div',{'class':['lectureInfo box']})
				lecInfo  = lecInfo.find('div',{'class':['top']})
				lectureInfo1 = lecInfo.find('div',{'class':'lec_name'}).find('span').contents[0]
				lectureInfo2 = lecInfo.find('div',{'class':'lec_profName'}).find('span').contents[0]
				lectureInfo3 = lec.findAll('div',{'class':'e'})[1].find('span',{'class':'content'}).contents[0]
				# evalList : json format
				lecEvalList = lec.find('input',{'id':['lectureEvalData']}).get('value')
				
			except KeyboardInterrupt:
				sys.exit()
			except urllib2.HTTPError as e:
				print "process %d : http exception!!!" % procId
				time.sleep(0.1)
				continue
			except urllib2.URLError as e:
				time.sleep(0.1)
				print "process %d : url exception!!!" % procId
				continue
			except socket.timeout as e:
				print "process %d : timeout exception!!!" % procId
				time.sleep(0.1)
				continue
			except Exception as e:
				print "process %d : %r" %procIde, e
				continue
			break

		print "%d : %dth lecture, ----- %d lectures left" % (procId,i,last-i)
	
		with open(directory+'/'+str(i)+'_eval.txt','w') as f:
			f.write(str(lecEvalList))
		with open(directory+'/'+str(i)+'_info.txt','w') as f:
			f.write(str(lectureInfo1)+'\n')
			f.write(str(lectureInfo2) + '\n')
			f.write(str(lectureInfo3))
			
		time.sleep(0.2)

	print "Process %d finished" % procId
	return


for i in xrange(0,12):
	processList.append(mp.Process(target=crawl_worker,args=(i,i*3000+1,(i+1)*3000)))
	print "process %d created" % (i+1)
processList.append(mp.Process(target=crawl_worker,args=(12,36001,39037)))
print "process %d created" % 13

for proc in processList:
	proc.start()

for proc in processList:
	proc.join()

print "crawlling finished"
