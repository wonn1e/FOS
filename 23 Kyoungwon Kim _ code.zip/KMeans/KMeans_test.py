# -*- coding: utf-8 -*-
from konlpy.tag import Twitter
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from pyspark.mllib.clustering import KMeans, KMeansModel
from numpy import array
#from math import sqrt
import math


def cal_cluster_sim(left,right):
	size = len(left)
	count = 0
	left_clusters = {}
	right_clusters = {}
	for l in left:
		if l not in left_clusters:
			left_clusters[l] = 1
		else:
			left_clusters[l] += 1
	for r in right:
		if r not in right_clusters:
			right_clusters[r] = 1
		else:
			right_clusters[r] += 1

	for k in left_clusters:
		if k in right_clusters:
			count += min(left_clusters[k],right_clusters[k])
	return 1/(abs(math.log(count/size + 1)) + 1)

sc = SparkContext()
sqlContext = SQLContext(sc)

normData = sc.pickleFile('/idf_kmeans')
clusters = KMeansModel.load(sc,'/KMeansModel')
data = normData.map(lambda x : (x.lec_code,clusters.predict(x.idf_norm))).groupByKey()#.reduceByKey( lambda (x,y) : x+y)

#f = open('test.txt','w')
#for a in data.take(3):
#	f.write(str(a))

#cluster_sim = data.cartesian(data).map(lambda (left,right) : ( (left[0],right[0]), cal_cluster_sim(left[1],right[1]) ))

cluster_sim = data.cartesian(data).map(lambda (left,right) : ( (left[0],right[0]),len(set(left[1]) & set(right[1])) / len(set(left[1])) ))

cluster_sim.saveAsPickleFile('/cluster_sim')

