# -*- coding: utf-8 -*-
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.feature import IDF
from pyspark.ml.feature import HashingTF, IDF, Tokenizer
from pyspark.ml.feature import Normalizer
from numpy import array


sc = SparkContext()
sqlContext = SQLContext(sc)

documents = sc.pickleFile('/idf_by_lec_code')
#lec_code, idf_norm
result = documents.cartesian(documents).map(lambda  (left,right) : ((left.lec_code,right.lec_code),left.idf_norm.dot(right.idf_norm)))

result.saveAsPickleFile('/cosine_result_pickle')
#result.saveAsTextFile('/cosine_result')

